package com.example.quizapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.WindowManager
import android.widget.Toast
import com.example.quizapp.databinding.ActivityMainBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var dataList:ArrayList<QuestionModel>
    var count:Int = 0
    var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)


        dataList = ArrayList<QuestionModel>()
        dataList.add(QuestionModel("What is the Capital of India?","Delhi","UttarPradesh","Punjab","Maharashtra","Delhi"))
        dataList.add(QuestionModel("What is the Capital of UttarPradesh?","Kanpur","Mathura","Lucknow","Banaras","Lucknow"))
        dataList.add(QuestionModel("Who is the PM of India?","Dr.ManMohan Singh","Narender Modi","Amit Shah","Yogi Adityanath","Narender Modi"))
        dataList.add(QuestionModel("Who is the CM of UP?","Mamta Benarji","Kejrival","Yogi Adityanath","Manoharlal Khattar ","Yogi Adityanath"))
        dataList.add(QuestionModel("How many states in India?","27","32","28","24","28"))

        binding.question.setText(dataList.get(0).question)
        binding.option1.setText(dataList.get(0).option1)
        binding.option2.setText(dataList.get(0).option2)
        binding.option3.setText(dataList.get(0).option3)
        binding.option4.setText(dataList.get(0).option4)

        binding.option1.setOnClickListener {
            nextData(binding.option1.text.toString())
        }
        binding.option2.setOnClickListener {
            nextData(binding.option2.text.toString())
        }
        binding.option3.setOnClickListener {
            nextData(binding.option3.text.toString())
        }
        binding.option4.setOnClickListener {
            nextData(binding.option4.text.toString())
        }
    }

    private fun nextData(i: String) {
        if(count<dataList.size){
            if(dataList.get(count).ans.equals(i)){
                score++
            }
        }

        count++
        if(count>=dataList.size){
            val intent = Intent(this,ScoreActivity::class.java)
            intent.putExtra("SCORE",score)
            startActivity(intent)
            finish()
        }
        else{
            binding.question.setText(dataList.get(count).question)
            binding.option1.setText(dataList.get(count).option1)
            binding.option2.setText(dataList.get(count).option2)
            binding.option3.setText(dataList.get(count).option3)
            binding.option4.setText(dataList.get(count).option4)
        }

    }
}
