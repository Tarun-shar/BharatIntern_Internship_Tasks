package com.example.temperatureconverter

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.temperatureconverter.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    lateinit var binding:ActivityMainBinding

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN)

        binding.btnCToF.setOnClickListener {

            if(binding.temperature.text.isNotEmpty()){
                val temp = binding.temperature.text.toString().toDouble()
                val tempInFahrenheit:Double = (temp * 9 / 5) + 32
                binding.result.text = "Temp is $temp°C and $tempInFahrenheit°F"
            }
            else{
                binding.temperature.error = "Please Enter the Value"
            }
        }

        binding.btnFToC.setOnClickListener {

            if(binding.temperature.text.isNotEmpty()){
            val temp = binding.temperature.text.toString().toDouble()
                val tempInCelsius:Double = (temp - 32)* 5/9
                binding.result.text = "Temp is $temp°F and $tempInCelsius°C"
            }
            else{
                binding.temperature.error = "Please Enter the Value"
            }
        }

    }
}